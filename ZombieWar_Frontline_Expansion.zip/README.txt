ZOMBIE WAR: FRONTLINE - ACTUALIZACIÓN EXPANDIDA
================================================

Esta versión amplía el prototipo original y mantiene el proyecto Android
(WebView) y el juego HTML5 Canvas en app/src/main/assets/index.html.

NOVEDADES
- Menú principal y selección de tres zonas: Normandía, Ardenas y Berlín.
- Progresión de oleadas con dificultad creciente y amenaza especial cada cinco oleadas.
- Cuatro equipos arcade intercambiables: Fusil, Subfusil, Escopeta y Apoyo.
- Cargadores, reserva de munición y recarga.
- Enemigos normales, veloces y resistentes.
- Suministros que aparecen durante la partida: botiquines y munición.
- Habilidad de pulso que se carga al superar enemigos.
- Obstáculos, trincheras y ambientación distinta por mapa.
- Pausa, pantalla de fin de misión, estadísticas y récord local.
- Controles táctiles y controles de teclado para probar en PC.

CONTROLES ANDROID
- Flechas: moverse.
- DISPARAR: mantener para atacar automáticamente al enemigo más cercano.
- RECARGAR: reponer el cargador usando la reserva.
- CAMBIAR: alternar el equipo.
- PULSO: habilidad de área cuando llega al 100%.
- Botón II: pausar.

PROBAR SIN COMPILAR
Extraé el ZIP y abrí app/src/main/assets/index.html con un navegador moderno.

GENERAR APK
El ZIP contiene el proyecto fuente Android y el workflow .github/workflows/build-apk.yml.
Subí el contenido del proyecto a un repositorio GitHub y ejecutá el workflow
"Build Zombie War APK" desde la pestaña Actions. Descargá el artefacto generado.
Este paquete es código fuente; no incluye un APK compilado.
